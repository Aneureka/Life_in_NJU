package cn.edu.nju.service;

/**
 * @author hiki on 2017-12-30
 */

public interface CustomerService {

    boolean login(int id, String password);
}
