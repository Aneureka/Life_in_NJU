package cn.edu.nju.util;

/**
 * @author hiki on 2018-01-11
 */

public class PageHelper {

    public static final int PAGE_SIZE = 20;

}
