package cn.edu.nju.util;

/**
 * @author hiki on 2017-12-18
 */

public class PageHelper {

    public static final int PAGE_SIZE = 20;

}
