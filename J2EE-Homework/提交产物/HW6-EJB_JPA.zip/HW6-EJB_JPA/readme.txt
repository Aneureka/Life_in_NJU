### 说明

1. persistence.xml分为两种配置，hibernate（部署）和 eclipselink（测试）
